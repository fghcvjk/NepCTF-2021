<?php
return [
    // 系统版本号
    'VERSION' => '2.3.8',
    'RELEASE' => '20181218',
];
