<?php

/**
 * 各项目独立的部署变量配置文件，请将此文件在发布平台中设置为"共享文件"
 */

return [
    'project_id' => 4,
    'environment_id' => 10,
    'vhash' => '9febdb6412680f1d9387dd302c2a871b',
];