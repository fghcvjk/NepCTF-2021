<?php

namespace app\common\model;

use think\Model;

class ComplaintMessage extends Model
{

}
