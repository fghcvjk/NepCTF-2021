#/bin/bash
echo $FLAG > /flag
export FLAG=not_flag