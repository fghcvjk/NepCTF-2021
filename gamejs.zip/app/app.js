var opn = require('opn');
var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var highestScore = 40000;
var FUNCFLAG = '_$$ND_FUNC$$_';
var serialize_banner = '{"banner":"好，很有精神！"}';
var flag = {"flag":""} // flag是啥来着？记不清了。

function Record() {
    this.lastScore = 0;
    this.maxScore = 0;
    this.lastTime = null;
}
var validCode = function (func_code){
    let validInput = /subprocess|mainModule|from|buffer|process|child_process|main|require|exec|this|eval|while|for|function|hex|char|base64|"|'|\[|\+|\*/ig;
    return !validInput.test(func_code);
};
var validInput = function (input) {
    let validInput = /subprocess|mainModule|from|process|child_process|main|require|exec|this|function|buffer/ig;
    ins = serialize(input);
    return !validInput.test(ins);
};
var merge = function (target, source) {
    try {
        for (let key in source) {
            if (typeof source[key] == 'object') {
                merge(target[key], source[key]);
            } else {
                target[key] = source[key];
            }
        }
    }
    catch (e) {
        console.log(e);
    }
};
var serialize = function (obj, ignoreNativeFunc, outputObj, cache, path) {
    path = path || '$';
    cache = cache || {};
    cache[path] = obj;
    outputObj = outputObj || {};
    if (typeof obj === 'string') {
      return JSON.stringify(obj);
    }
    var key;
    for (key in obj) {
      if (obj.hasOwnProperty(key)) {
        if (typeof obj[key] === 'function') {
          var funcStr = obj[key].toString();
          outputObj[key] = FUNCFLAG + funcStr;
        } else {
          outputObj[key] = obj[key];
        }
      }
    }
    return JSON.stringify(outputObj);
};
var unserialize = function(obj) {
    obj = JSON.parse(obj);
    if (typeof obj === 'string') {
      return obj;
    }
    var key;
    for(key in obj) {
      if(typeof obj[key] === 'string') {
        if(obj[key].indexOf(FUNCFLAG) === 0) {
          var func_code=obj[key].substring(FUNCFLAG.length);
          if (validCode(func_code)){
            var d = '(' + func_code + ')';
            obj[key] = eval(d);
          }
        }
      }
    }
    return obj;
};
app.use(bodyParser());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'views')));

app.use(function (req, res, next) {
    if (validInput(req.body)) {
        next();
    } else {
        res.status(403).send('Hacker!!!');
    }
});
async function index(req, res) {
    res.sendFile(path.resolve(__dirname, 'static/index.html'));
}
async function record(req, res, next) {
    new Promise(function (resolve, reject) {
        var record = new Record();
        var score = req.body.score;
        if (score.length < String(highestScore).length) {
            merge(record, {
                lastScore: score,
                maxScore: Math.max(parseInt(score),record.maxScore),
                lastTime: new Date().toString()
            });
            highestScore = highestScore > parseInt(score) ? highestScore : parseInt(score);
            if ((score - highestScore) < 0) {
                var banner = "不好，没有精神！";
            } else {
                var banner = unserialize(serialize_banner).banner;
            }
        }
        res.json({
            banner: banner,
            record: record
        });
    }).catch(function (err) {
        next(err)
    })
}

app.post('/record', record);
app.get('/', index);
app.get('/source', function (req, res) {
    res.sendFile(path.join(__dirname, 'gamejs_source.js'));
})
app.use(function (err, req, res, next) {
    console.log(err.stack);
    res.status(500).send('Some thing broke!')
});
app.listen('3000');