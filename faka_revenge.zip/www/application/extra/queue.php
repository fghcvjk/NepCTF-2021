<?php


return [
    'connector' => 'Sync'
];
